from models import Employee, Student
from db_config import db

# Connect Employees to Students based on the student interest and employee role
def connect_employees_to_students(student_id):
    student = Student.query.filter_by(id=student_id).first()
    if not student:
        return []

    # Find employees with matching interests
    employees = Employee.query.filter(Employee.role.ilike(f'%{student.interest}%')).all()
    connections = []
    for emp in employees:
        connections.append({
            'student': student.interest,
            'employee': emp.empname,
            'role': emp.role,
            'company': emp.company
        })
    return connections
