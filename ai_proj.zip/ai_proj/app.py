from flask import Flask, render_template, request
from ai_utils import connect_employees_to_students
from dotenv import load_dotenv
import os

load_dotenv()

app = Flask(__name__)

@app.route('/')
def index():
    return render_template('index.html')

@app.route('/generate_team')
def generate_team():
    return render_template('generate_team.html')

@app.route('/personal_statement')
def personal_statement():
    return render_template('personal_statement.html')

@app.route('/connect', methods=['GET', 'POST'])
def connect():
    connections = []
    if request.method == 'POST':
        user_id = request.form['user_id']
        connections = connect_employees_to_students(user_id)
    return render_template('connect.html', connections=connections)

if __name__ == '__main__':
    app.run(debug=True)
