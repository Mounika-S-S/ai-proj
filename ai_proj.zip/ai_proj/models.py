from sqlalchemy import Column, Integer, String, ForeignKey, Date
from sqlalchemy.orm import relationship
from db_config import db

# Person Table
class Person(db.Model):
    __tablename__ = 'person'
    id = Column(Integer, primary_key=True)
    name = Column(String)
    phone = Column(String)
    email = Column(String)
    address = Column(String)
    dob = Column(Date)

    employee = relationship("Employee", back_populates="person", uselist=False)
    student = relationship("Student", back_populates="person", uselist=False)

# Department Table
class Department(db.Model):
    __tablename__ = 'department'
    id = Column(Integer, primary_key=True)
    name = Column(String)
    description = Column(String)
    head_id = Column(Integer)

    employees = relationship("Employee", back_populates="department")

# Employee Table
class Employee(db.Model):
    __tablename__ = 'employee'
    person_id = Column(Integer, ForeignKey('person.id'), primary_key=True)
    employee_id = Column(Integer)
    empname = Column(String)
    dept_id = Column(Integer, ForeignKey('department.id'))
    experience = Column(Integer)
    role = Column(String)
    company = Column(String)
    hire_date = Column(Date)
    salary = Column(Integer)
    phone = Column(String)
    project_id = Column(Integer, ForeignKey('project.id'))
    team_id = Column(Integer, ForeignKey('team.teamid'))

    department = relationship("Department", back_populates="employees")
    project = relationship("Project", back_populates="employees")
    person = relationship("Person", back_populates="employee")
    team = relationship("Team", back_populates="members")
    workings = relationship("Working", back_populates="employee")
    credentials = relationship("Credentials", back_populates="employee")

# Project Table
class Project(db.Model):
    __tablename__ = 'project'
    id = Column(Integer, primary_key=True)
    compid = Column(Integer)
    name = Column(String)
    description = Column(String)
    startdate = Column(Date)
    enddate = Column(Date, nullable=True)
    status = Column(String)
    teamid = Column(Integer, ForeignKey('team.teamid'))

    # Explicitly specify foreign_keys to resolve ambiguity
    team = relationship("Team", back_populates="projects", foreign_keys=[teamid])
    employees = relationship("Employee", back_populates="project")

# Team Table
class Team(db.Model):
    __tablename__ = 'team'
    teamid = Column(Integer, primary_key=True)
    projid = Column(Integer, ForeignKey('project.id'))
    name = Column(String)
    description = Column(String)
    lead_id = Column(Integer)

    # Explicitly specify foreign_keys to resolve ambiguity
    project = relationship("Project", back_populates="team", foreign_keys=[projid])

    members = relationship("Employee", back_populates="team")
    projects = relationship("Project", back_populates="team")

# Working Table
class Working(db.Model):
    __tablename__ = 'working'
    id = Column(Integer, primary_key=True)
    employee_id = Column(Integer, ForeignKey('employee.employee_id'))
    projectid = Column(Integer, ForeignKey('project.id'))
    assigned_date = Column(Date)
    role_in_team = Column(String)
    teamid = Column(Integer, ForeignKey('team.teamid'))

    employee = relationship("Employee", back_populates="workings")
    project = relationship("Project")
    team = relationship("Team")

# Credentials Table
class Credentials(db.Model):
    __tablename__ = 'credentials'
    id = Column(Integer, primary_key=True)
    empid = Column(Integer, ForeignKey('employee.employee_id'))
    credential_type = Column(String)
    credential_value = Column(String)
    issue_by = Column(String)
    issued_date = Column(Date)
    expiry_date = Column(Date)

    employee = relationship("Employee", back_populates="credentials")

# Student Table
class Student(db.Model):
    __tablename__ = 'student'
    id = Column(Integer, primary_key=True)
    personid = Column(Integer, ForeignKey('person.id'))
    admission_number = Column(String)
    year = Column(Integer)
    program = Column(String)
    admission_date = Column(Date)
    dept_id = Column(Integer, ForeignKey('department.id'))
    lang = Column(String)
    interest = Column(String)

    department = relationship("Department")
    person = relationship("Person", back_populates="student")
